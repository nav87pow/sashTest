$('.aboutinfo').on('click',function(){
  $('.aboutinfo').css('bottom', '12vh')
})